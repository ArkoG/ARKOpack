-- Format for overwriting define values:
--
-- NDefines.NDiplomacy.DEMESNE_BASE_MAX_SIZE = 2.0
	NDefines.NGraphics.CITY_SPRAWL_AMOUNT = 0.3